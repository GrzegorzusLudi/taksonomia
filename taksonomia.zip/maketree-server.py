
import json
import http.server
import socketserver

columns = []
records = {}
nameMap = {}

length = 336955
with open("dataset.csv") as f:
    firstline = True
    j = 0
    for line in f:
        line = line.strip()
        
        if firstline:
            columns = list(map(lambda x: x[1:-1],line.split(',')))
            firstline = False
        else:
            record = {}
            fields = list(map(lambda x: x[1:-1],line.split(',')))
            for i in range(len(fields)):
                record[columns[i]] = fields[i]
            
            nameMap[record['taxon_name']] = record['taxon_no']
            records[record['taxon_no']] = {'record':record, 'children':[], 'childrenTaxa':{}}
        j+=1
        if (j % 10000) == 0:
            print(j,'/',length)

right_taxon = ['domain','kingdom','phylum','class','order','family','genus','species']
next_taxon = {'domain':'kingdom','kingdom':'phylum','phylum':'class','class':'order','order':'family','family':'genus','genus':'species'}

for rec in records:
    record = records[rec]
    sub = record['record']
    name = sub['taxon_name']
    record['name'] = name
    parent = sub['parent_no']
    if parent in records:
        records[parent]['children'].append(sub['taxon_no'])
        record['parent_no'] = parent
    elif sub['parent_name'] in nameMap:
        parent = nameMap[sub['parent_name']]
        records[parent]['children'].append(sub['taxon_no'])
        record['parent_no'] = parent
    else:
        print(name)

def addParent(record):
    #desc = record['records'][0]
    #print(desc['taxon_name'],"\t[",desc['firstapp_max_ma'],'-',desc['firstapp_min_ma'],',',desc['lastapp_max_ma'],'-',desc['lastapp_min_ma'],"]\tspecies: ",desc['n_species'],"\n\t","\n\t".join(record['children']))
    
    sub = record['record']
    parent = sub['parent_no']
    if parent in records:
        newParent = json.loads(json.dumps(records[parent]))
        #del newParent['children']
        record['parent'] = newParent
    elif sub['parent_name'] in nameMap:
        parent = nameMap[sub['parent_name']]
        newParent = json.loads(json.dumps(records[parent]))
        record['parent'] = newParent

        
#for rec in records:
    #record = records[rec]
    #name = record['record']['taxon_name']
    #with open("tree3/"+name[0]+"/"+name+".json",'w') as f:
        #newContent = json.dumps(record)
        #f.write(newContent)
      
      
def fill_taxon_until_right_taxon(taxon,rank):
    traversed_nodes = [taxon['record']['taxon_no']]
    level = 0
    potentialChildren = []
    childrenleft = 0
    new_rank = rank
    for t in right_taxon:
        if t in taxon['record'] and taxon['record'][t] != '':
            new_rank = t
    
        
    fill_taxon_until_right_taxon_rec(taxon,new_rank,traversed_nodes,level)
    
    addParent(taxon)
    
    #alreadySearched = [taxon]
    #for child in taxon['children']:
        #if child not in taxon['childrenTaxa']:
            #newChild = json.loads(json.dumps(records[child]))
            #taxon['childrenTaxa'][child] = newChild
            #potentialChildren.append(newChild)
            
            #newChild['name'] = newChild['record']['taxon_name']
            #newChild['childrenTaxa'] = {}
            #alreadySearched.append(newChild)
    
    #while len(potentialChildren) > 0:
        #newPotentialChildren = []
        #for c in potentialChildren:
            #if len(c['children']) > 1:
                #childrenleft += len(c['children']) - 1
                
            #for child in c['children']:
                #if child not in alreadySearched:
                    #newChild = json.loads(json.dumps(records[child]))
                    #c['childrenTaxa'][child] = newChild
                    #if(newChild['record']['taxon_rank'] != rank and newChild['record']['taxon_rank'] in right_taxon):
                        #return
                    #newPotentialChildren.append(newChild)
                    #alreadySearched.append(newChild)
            
                    #newChild['name'] = newChild['record']['taxon_name']
                    #newChild['childrenTaxa'] = {}
            
        #potentialChildren = newPotentialChildren
        
    
def fill_taxon_until_right_taxon_rec(taxon,rank,traversed_nodes,level):
    if rank in next_taxon: 
        nt = next_taxon[rank]
        if nt in taxon['record'] and taxon['record'][nt] != '':
            return
    
    for child in taxon['children']:
        newChild = json.loads(json.dumps(records[child]))
        if newChild['record']['taxon_no'] in traversed_nodes:
            continue
        
        traversed_nodes.append(newChild['record']['taxon_no'])
        
        taxon['childrenTaxa'][child] = newChild
        fill_taxon_until_right_taxon_rec(newChild,rank,traversed_nodes,level+1)
        
            
            
      

class MyHttpRequestHandler(http.server.SimpleHTTPRequestHandler):
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
    def do_GET(self):
        print("got request: "+self.path)
        if self.path == '/':
            self.path = 'index3.html'
            return http.server.SimpleHTTPRequestHandler.do_GET(self)
        else:
            path = self.path.split('/')[-1]
            if path[0] in ['0','1','2','3','4','5','6','7','8','9']:
                
                taxon = json.loads(json.dumps(records[path]))
                
                fill_taxon_until_right_taxon(taxon,taxon['record']['taxon_rank'])
                    
                self._set_headers()
                self.wfile.write(json.dumps(taxon).encode('utf-8'))
            else:
                try:
                    taxon_id = nameMap[path]
                    taxon = json.loads(json.dumps(records[taxon_id]))
                    
                    fill_taxon_until_right_taxon(taxon,taxon['record']['taxon_rank'])
                    
                    self._set_headers()
                    self.wfile.write(json.dumps(taxon).encode('utf-8'))
                except Exception as e:
                    print(e)
            
            print(self.path)
        #return http.server.SimpleHTTPRequestHandler.do_GET(self)


# Create an object of the above class
handler_object = MyHttpRequestHandler

PORT = 8001
my_server = socketserver.TCPServer(("", PORT), handler_object)

print("listening to port "+str(PORT))

# Star the server
my_server.serve_forever()

      
#z = 0
#for rec in records:
    #z += 1
    #record = records[rec]
    ##desc = record['records'][0]
    ##print(desc['taxon_name'],"\t[",desc['firstapp_max_ma'],'-',desc['firstapp_min_ma'],',',desc['lastapp_max_ma'],'-',desc['lastapp_min_ma'],"]\tspecies: ",desc['n_species'],"\n\t","\n\t".join(record['children']))

    #newRecord = json.loads(json.dumps(record))
    #name = record['record']['taxon_no']
    #newRecord['name'] = name
    #newRecord['childrenTaxa'] = {}
    
    ##print(z,newRecord['name'])
    #childrenleft = 0
    #potentialChildren = []
    #sub = newRecord['record']
    #parent = sub['parent_no']
    #if parent in records:
        #newParent = json.loads(json.dumps(records[parent]))
        #del newParent['children']
        #newRecord['parent'] = newParent
            
    #alreadySearched = [newRecord]
    #for child in newRecord['children']:
        #if child not in newRecord['childrenTaxa']:
            #newChild = json.loads(json.dumps(records[child]))
            #newRecord['childrenTaxa'][child] = newChild
            #potentialChildren.append(newChild)
            
            #newChild['name'] = newChild['record']['taxon_name']
            #newChild['childrenTaxa'] = {}
            #alreadySearched.append(newChild)
    
    #while childrenleft <= 10 and len(potentialChildren) > 0:
        #newPotentialChildren = []
        #for c in potentialChildren:
            #if len(c['children']) > 1:
                #childrenleft += len(c['children']) - 1
                
            #for child in c['children']:
                #if child not in alreadySearched:
                    #newChild = json.loads(json.dumps(records[child]))
                    #c['childrenTaxa'][child] = newChild
                    #newPotentialChildren.append(newChild)
                    #alreadySearched.append(newChild)
            
                    #newChild['name'] = newChild['record']['taxon_name']
                    #newChild['childrenTaxa'] = {}
            
        #potentialChildren = newPotentialChildren
            
        
    #for element in alreadySearched:
        #del element['children']
    
    #print(z)
    #with open("tree2/"+name[0]+"/"+name+".json",'w') as f:
        #newContent = json.dumps(newRecord)
        #f.write(newContent)
        











